Python 2.7 files needed for NatLink/Unimacro/Vocola :

Latest version of Python 2.7 (december 2016)

basic (python-2.7.12.msi)
pywin32 (windows extensions
wxPython (from www.wxpython.org, wxPython3.0-win32-3.0.2.0-py27.exe)
only needed for VoiceCode: PyXml (hard to find, found it on www.somethinkodd.com etc.)

Install for All Users.

Just install, most of the time, first 
the basic file (python-2.7.12.msi), then the other ones.

If this does not work:
Uninstall previous python versions first, and check the PATH system variable.
If things do not work this environment variable can be set to for example C:\python27 (can be done after all the installing, see below)

See also http://qh.antenna.nl/unimacro

Possibly in future different versions for 32-bit and 64-bit computers should be made.
For the moment only 32 bit installs of python can handle NatLink.

Please give feedback if you encounter these issues or others.

Quintijn Hoogenboom, December 2016

q.hoogenboom@antenna.nl

